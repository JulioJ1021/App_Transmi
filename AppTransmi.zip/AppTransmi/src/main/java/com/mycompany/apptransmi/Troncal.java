package com.mycompany.apptransmi;

/**
 *
 * @author Estudiante
 */
public abstract class Troncal {
    String Zonas[] = new String[12];
}
